@php
    $imagesActive = request('post_type') !== 'echoes';
    $echoesActive = request('post_type') === 'echoes';
@endphp

<nav
    class="safe-bottom fixed inset-x-0 bottom-0 z-50 w-full border-t border-sol-line bg-sol-panel/95 shadow-[0_-10px_30px_-24px_rgba(55,30,18,0.5)] backdrop-blur"
    aria-label="Profile navigation"
>
    <div class="mx-auto grid w-full max-w-300 grid-cols-3 px-4 sm:px-6 lg:px-8">
        {{-- My image posts --}}
        <a
            href="{{ url('/profile') }}"
            class="{{ $imagesActive ? 'text-sol-mars' : 'text-sol-muted hover:text-sol-mars' }}
                group relative flex min-h-16 flex-col items-center justify-center gap-1 font-body transition"
            @if ($imagesActive) aria-current="page" @endif
        >
            @if ($imagesActive)
                <span class="absolute inset-x-0 top-0 h-0.5 bg-sol-orange"></span>
            @endif

            <svg
                class="size-6 transition group-hover:-translate-y-0.5"
                viewBox="0 0 28 28"
                fill="none"
                stroke="currentColor"
                stroke-width="1.5"
                aria-hidden="true"
            >
                <rect x="3.5" y="5.5" width="21" height="16"></rect>
                <circle cx="9" cy="10.5" r="1.5"></circle>
                <path d="m5.5 19 4.5-4.5 3 3 2.5-2.5 6 6"></path>
            </svg>

            <span class="text-[9px] font-bold uppercase tracking-[0.18em]">
                My images
            </span>
        </a>

        {{-- Create posts --}}
        <div class="grid min-h-16 grid-cols-2">
            <a
                href="{{ url('/sol/create') }}"
                class="group relative grid place-items-center text-sol-muted transition hover:bg-sol-paper hover:text-sol-orange"
                aria-label="Create image post"
                title="Create image post"
            >
                <svg
                    class="size-7 transition group-hover:-translate-y-0.5"
                    viewBox="0 0 28 28"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.5"
                    aria-hidden="true"
                >
                    <rect x="3.5" y="5.5" width="17" height="16"></rect>
                    <circle cx="9" cy="10.5" r="1.5"></circle>
                    <path d="m5.5 19 4.5-4.5 3 3 2.5-2.5 3 3"></path>

                    <path d="M23 3.5v7M19.5 7h7"></path>
                </svg>

                <span
                    class="absolute bottom-2 size-1 bg-sol-orange opacity-0 transition group-hover:opacity-100"
                    aria-hidden="true"
                ></span>
            </a>

            <a
                href="{{ url('/echoes/create') }}"
                class="group relative grid place-items-center text-sol-muted transition hover:bg-sol-paper hover:text-sol-orange"
                aria-label="Create text post"
                title="Create text post"
            >
                <svg
                    class="size-7 transition group-hover:-translate-y-0.5"
                    viewBox="0 0 28 28"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.5"
                    aria-hidden="true"
                >
                    <path d="M4 7.5h11M4 12h9M4 16.5h7"></path>
                    <path d="m14.5 21 1-4 7.5-7.5 3 3-7.5 7.5-4 1Z"></path>
                    <path d="m21.5 11 3 3"></path>

                    <path d="M22.5 3v5M20 5.5h5"></path>
                </svg>

                <span
                    class="absolute bottom-2 size-1 bg-sol-orange opacity-0 transition group-hover:opacity-100"
                    aria-hidden="true"
                ></span>
            </a>
        </div>

        {{-- My text posts --}}
        <a
            href="{{ url('/profile?post_type=echoes') }}"
            class="{{ $echoesActive ? 'text-sol-mars' : 'text-sol-muted hover:text-sol-mars' }}
                group relative flex min-h-16 flex-col items-center justify-center gap-1 font-body transition"
            @if ($echoesActive) aria-current="page" @endif
        >
            @if ($echoesActive)
                <span class="absolute inset-x-0 top-0 h-0.5 bg-sol-orange"></span>
            @endif

            <svg
                class="size-6 transition group-hover:-translate-y-0.5"
                viewBox="0 0 28 28"
                fill="none"
                stroke="currentColor"
                stroke-width="1.5"
                aria-hidden="true"
            >
                <path d="M4 7.5h11M4 12h9M4 16.5h7"></path>
                <path d="m14.5 21 1-4 7.5-7.5 3 3-7.5 7.5-4 1Z"></path>
                <path d="m21.5 11 3 3"></path>
            </svg>

            <span class="text-[9px] font-bold uppercase tracking-[0.18em]">
                My echoes
            </span>
        </a>
    </div>
</nav>
